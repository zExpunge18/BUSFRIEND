package com.example.driverapp3;

public class Links {
    //public static final String ROOT_URL = "http://192.168.137.1/redhanasushi/";
    public static final String ROOT_URL ="https://sylas123.000webhostapp.com/";
    public static final String LOGIN = ROOT_URL + "mobile/login_User";
    public static final String REGSITER = ROOT_URL + "mobile/Register";
    public static final String Load_Buslist = ROOT_URL + "mobile/Load_BusList";
    public static final String Book_Ticket = ROOT_URL + "mobile/Book_Ticket";
    public static final String LoadTransactionHistory = ROOT_URL + "mobile/LoadTransactionHistory";
}
